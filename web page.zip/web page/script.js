function showMessage() {
    alert("Hello! You clicked the button ");
}

function changeText() {
    document.getElementById("title").innerHTML = "Title Changed!";
}

function changeColor() {
    document.body.style.backgroundColor = "lightblue";
}
function sendForm(event) {
    event.preventDefault();
    alert("Form submitted successfully 😊");
}